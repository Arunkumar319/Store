﻿using Final;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Final
{
    /// <summary>
    /// Interaction logic for NewProduct.xaml
    /// </summary>
    public partial class NewProduct : Window
    {
        public NewProduct()
        {
            InitializeComponent();
            DBNorthwindEntities db = new DBNorthwindEntities();
            foreach (var cate in db.Categories)
            {
                combobox.Items.Add(cate.CategoryName);
            }
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            DBNorthwindEntities db = new DBNorthwindEntities();

            if (name.Text == "" || combobox.Text == "" || price.Text =="" )
            {
                MessageBox.Show("Invalid input");
                return;
            }

            db.Products.Add(new Product
            {
                ProductName = name.Text,
                Category = new Category { CategoryName = combobox.Text },
                UnitPrice = decimal.Parse(price.Text),
            });
            db.SaveChanges();
            MessageBox.Show("Operation Successfull!");
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
