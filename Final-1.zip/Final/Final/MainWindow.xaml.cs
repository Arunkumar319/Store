﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Final;

namespace Final
{
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void allproducts_Click(object sender, RoutedEventArgs e)
        {
            DBNorthwindEntities db = new DBNorthwindEntities();

            productsdatagrid.ItemsSource = db.Products.ToList();

            foreach(var cate in db.Categories)
            {
                combobox.Items.Add(cate.CategoryName);
            }
        }

        private void search_Click(object sender, RoutedEventArgs e)
        {
            DBNorthwindEntities db = new DBNorthwindEntities();

            var productsList = from product in db.Products where product.ProductName.Contains(name.Text) select product;

            productsdatagrid.ItemsSource = productsList.ToList();
        }

        private void getcategory(object sender, SelectionChangedEventArgs e)
        {
            DBNorthwindEntities db = new DBNorthwindEntities();
            var productsList = from product in db.Products where product.Category.CategoryName==combobox.Text select product;

            productsdatagrid.ItemsSource = productsList.ToList();
        }

        private void clearData_Click(object sender, RoutedEventArgs e)
        {
            combobox.Items.Clear();
            productsdatagrid.ItemsSource = null;
        }

        private void newproduct_Click(object sender, RoutedEventArgs e)
        {
            new NewProduct().ShowDialog();
        }
    }
}
